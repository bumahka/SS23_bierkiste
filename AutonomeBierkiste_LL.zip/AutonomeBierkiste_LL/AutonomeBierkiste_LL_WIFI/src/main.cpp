/*
 * Project: Autonome Bierkiste SS23
 * At the MMT faculty, students collaboratively developed a beer crate with an electric drive.
 * Following that, the code for the autonomous driving function of the beer crate was implemented.
 * In this process, C++ proved to be the ideal programming language for this task.
 *
 * Created by: Gabriel Boehm, Isabel Kraus, Walter Orlov, Dennis Schell
 *
 */

/* All necessary classes */
#include <Arduino.h>
#include "uart_message.h"
#include "uart_message.cpp"
#include <AccelStepper.h>
#include "antriebsmotor.h"
#include "antriebsmotor.cpp"
#include "pins.h"
#include "sensors.h"
#include "sensors.cpp"
#include "bremse.h"
#include "bremse.cpp"
#include "PID.h"
#include "emergency_button.h"
#include <WiFi.h>
#include <RemoteXY.h>
#include <iostream>
// #include "PID.cpp"
#include <esp_task_wdt.h> /* Load Watchdog-Library */

/* defines */
// #define WDT_TIMEOUT_SECONDS 10
/* global variables */
TaskHandle_t Task_Sensors;
TaskHandle_t Task_Steering;
TaskHandle_t Task_Speed;
TaskHandle_t Task_Emergency_Button;
SemaphoreHandle_t mySemaphore;
SemaphoreHandle_t Semaphore_Steering;
/* timer variables */
hw_timer_t *timer = NULL;
uint32_t counter1ms = 0;
bool flagSensor = false;
volatile bool flagISR = false;

/*Emergency button*/
int emergencyButtonPressed = 0; // 0 =nothing, 1 = button off, 2 = button on
bool emergencyButtonMode = false;

int16_t steering_val = 0;
byte direction = 0;
uint16_t speed = 270;
uint16_t distances[3];

/* global objets */
AccelStepper stepper(AccelStepper::FULL4WIRE,
                     P_STEERING_PULSE,
                     N_STEERING_PULSE,
                     P_STEERING_DIRECTION,
                     N_STEERING_DIRECTION,
                     true); // 4 wire full stepper
UartMessage myUart(rx_pin, tx_pin, 115200, SERIAL_8N1);
antrieb myAntrieb(out_driveThrottle, out_driveDirection);
Break myBreak(myAntrieb, mySemaphore);
sensor mySensors(sensorLeft_trigger,
                 sensorRight_trigger,
                 sensorMiddle_trigger,
                 sensorLeft_echo,
                 sensorRight_echo,
                 sensorMiddle_echo,
                 myBreak);

/* Function prototypes */
void setup();
void loop();
void sensorMain(void *parameter);
void steeringMain(void *parameter);
void speedMain(void *parameter);
void timer_init();
void stepper_init();
uint16_t runPIDControl(int speed);
void handleEncoderInterrupt();
void emergencyButton(void *parameter);
//void IRAM_ATTR onTimer();

uint16_t curr_speed = 0;

portMUX_TYPE synch = portMUX_INITIALIZER_UNLOCKED;

/* Setup function
 * initialisation of timer, stepper and watchdog
 */
CRemoteXY *remotexy;
void setup()
{
  //timer_init();
  //myAntrieb.setSaveState();

  /* Watchdog Setup */
  // esp_task_wdt_init(WDT_TIMEOUT_SECONDS, true); /* Init Watchdog with 5 seconds timeout and panicmode */
  // esp_task_wdt_add(NULL);                       /* No special task executed before restart */
  pinMode(SPEED_SENSOR_A, INPUT);
  pinMode(SPEED_SENSOR_B, INPUT);
  Serial.begin(115200);
  Serial.println("Setup done");
  myBreak.Deactivate_EmergencyBreak();
  attachInterrupt(digitalPinToInterrupt(SPEED_SENSOR_A), handleEncoderInterrupt, CHANGE);
  flagSensor = true;


  /* mulitcore setup */
  if (xPortGetCoreID() == 1)
  {
    xTaskCreatePinnedToCore(sensorMain, "TaskSensor", 4096, NULL, tskIDLE_PRIORITY, &Task_Sensors, 0);
  }
  else
  {
    xTaskCreatePinnedToCore(sensorMain, "TaskSensor", 4096, NULL, tskIDLE_PRIORITY, &Task_Sensors, 1);
  }

  xTaskCreate(steeringMain, "TaskSteering", 2000, NULL, 0, &Task_Steering);
  xTaskCreate(speedMain, "TaskSpeed", 4096, NULL, 0, &Task_Speed);
  xTaskCreatePinnedToCore(emergencyButton, "TaskEmergencyButton", 3000, NULL, tskIDLE_PRIORITY, &Task_Emergency_Button, 0);
  /* Semaphore setup */
  mySemaphore = xSemaphoreCreateMutex();
  Semaphore_Steering = xSemaphoreCreateMutex();

  
}

/* Loop function
 * endless loop, controls the autonomous driving
 */
void loop()
{

  /* execute the distance reading every 20ms */
  flagSensor = true;
  if (flagSensor)
  {
    // Serial.print(counter1ms);
    // Serial.println(" - measure");
    mySensors.readDistance();
    flagSensor = false;

    if (!mySensors.distanceOK())
    {
      myBreak.Activate_EmergencyBreak();
    }
    else
    {
      myBreak.Deactivate_EmergencyBreak();
    }
  }

  /* check for messages in the UART */
  if (myUart.msgAvailable())
  {
    if (myUart.availableForTransmit())
    {
      for (int i = 0; i < sizeof(distances); i++)
      {
        distances[i] = mySensors.getDistance(i + 1);
      }
      myUart.transmitDistances(distances);
    }

    /* read the instructions from the surface */
    myUart.getInstructions();

    /* Only deactivate Emergency if distance correct */
    if (mySensors.distanceOK())
    {
      if (myBreak.get_State_Break())
      {
        myBreak.Deactivate_EmergencyBreak();
      }

      /* set direction  */
      myUart.getDirection(direction);
      myAntrieb.setDirection(direction);

      /* set the steering */
      myUart.getSteering(steering_val);
      Serial.print("Steering: ");
      Serial.println(steering_val);
      /* Provide a good moveTo function. Diffrent Thread for Steering */
      if (xSemaphoreTake(Semaphore_Steering, portMAX_DELAY) == pdTRUE)
      {
        stepper.moveTo(steering_val * (-4)); // negative anticlockwise

      }
      xSemaphoreGive(Semaphore_Steering);

    }
  }
  //esp_task_wdt_reset(); // reset watchdog timer
}

void emergencyButton(void *parameter){

  
  remotexy = new CRemoteXY (
    RemoteXY_CONF_PROGMEM, 
    &RemoteXY, 
    new CRemoteXYConnectionServer (
      new CRemoteXYComm_WiFiPoint (
        "Bierkiste",       // REMOTEXY_WIFI_SSID
        "12345678"),        // REMOTEXY_WIFI_PASSWORD
      6377                  // REMOTEXY_SERVER_PORT
    )
  );
  
  for(;;){
    remotexy->handler();
    if (remotexy->isConnected()){
      RemoteXY.indicator_led = (RemoteXY.Switch==0)?1:2;
      if (RemoteXY.Switch==0){
        emergencyButtonPressed = 1;
        Serial.println("STOP");
      }
      else if (RemoteXY.Switch==1){
        emergencyButtonPressed = 2;
        Serial.println("Go");
      }
    }
    vTaskDelay(50/portTICK_PERIOD_MS);
    //esp_task_wdt_reset();
  }

}
void sensorMain(void *parameter)
{
  for (;;)
  {
    /* execute the distance reading every 20ms */
    if (flagSensor)
    {
      mySensors.readDistance();
      flagSensor = false;
    }

    // esp_task_wdt_reset();
  }
}

void steeringMain(void *parameter)
{
  stepper_init();
  for (;;)
  {
    while (stepper.distanceToGo() != 0)
    {
      stepper.run();
    }
  }
}

void speedMain(void *parameter){
  
  // Set up the PID controller
  myPID.SetMode(AUTOMATIC);
  myPID.SetOutputLimits(0, 255);  // Limit PWM output to 0-255
  myPID.SetSampleTime(10);  // Set PID computation interval (ms)

  for (;;){
      /* set the speed */
      myUart.getSpeed(speed);

      if (speed > 125 || emergencyButtonPressed == 1 || emergencyButtonPressed == 0){
        //speed = 0;
        curr_speed= runPIDControl(0);
      }
      else if (emergencyButtonPressed == 2){
       // Serial.println(speed);
        //int mapped_speed = map(speed, 70, 125, 0, 30);
        //Serial.println(mapped_speed);
        //curr_speed= runPIDControl(speed);
       // Serial.println(curr_speed);

      }
      //myAntrieb.setSpeed(speed);
     // Serial.println(curr_speed);
     // Serial.println();
      myAntrieb.setSpeed(curr_speed);
      vTaskDelay(10/portTICK_PERIOD_MS);
  }
}
/* Timer initialisation */

// void timer_init()
// {
//   timer = timerBegin(0, 80, true);            /* Timer_0, prescaling: 80MHz / 80 = 1MHz -> T=1 us */
//   timerAttachInterrupt(timer, onTimer, true); /* Interrupt Funktion onTimer() */
//   timerAlarmWrite(timer, 1000, true);         /* Faktor für Timer z.B. 1000000*1us = 1s */
//   timerAlarmEnable(timer);
// }

/* Initialisation of stepper */
void stepper_init()
{

  stepper.setAcceleration(6000); /* Acceleration in steps/s^2 */
  stepper.setMaxSpeed(5000);     /* Speed in steps/s */
  stepper.setSpeed(4000);
  stepper.enableOutputs();
  stepper.setMinPulseWidth(20); /* 20 microseconds */
}

/* Timer interrupt service routine */
/*
void IRAM_ATTR onTimer()
{
  counter1ms++;
  if (counter1ms % 90 == 0)
  {
    flagSensor = true;
  }
}*/

void handleEncoderInterrupt() {
    int channelAState = digitalRead(SPEED_SENSOR_A); // Read the state of Channel A
    int channelBState = digitalRead(SPEED_SENSOR_B); // Read the state of Channel B

  // Determine direction based on the state of Channel B
  if (channelBState != channelAState) {
    counter--;  // Moving forward
  } else {
    counter++;  // Moving backward
  }
}


uint16_t runPIDControl(int speed){
  unsigned long currentTime = millis();  // Get the current time
  setpoint = speed;  // Set the target speed (RPM)
  if (setpoint == 0){
    
    input = 0;
    output = 0;
    counter = 0;
    previousCounter = 0;
    myPID.SetMode(MANUAL);
    filteredOutput = 0;
    if (filteredOutput < 0){
      filteredOutput = 0;
    }
    // Serial.print("Current PWM: ");
    // Serial.println(filteredOutput);
  }
  else{
        if (currentTime - lastTime >= interval) {
          // Calculate the change in position during the interval
          myPID.SetMode(AUTOMATIC);
          int positionChange = counter - previousCounter;
          previousCounter = counter;  // Update the previous counter value

          // Calculate motor speed in counts/second
          float speedInCountsPerSecond = positionChange / (interval / 1000.0);

          // Calculate motor RPM
          input = (speedInCountsPerSecond * 60) / encoderCPR;

          // Compute PID output (PWM value for motor speed control)
          myPID.Compute();

        
          //anti-windup
         double ITerm = myPID.GetITerm();
          if(ITerm > integralLimit){
            ITerm = integralLimit;
          }
          else if (ITerm < -integralLimit){
            ITerm = -integralLimit;
          }
          myPID.SetITerm(ITerm);
          filteredOutput = alpha * output + (1 - alpha) * filteredOutput;

          // Set motor direction based on the setpoint (direction of rotation)
          //digitalWrite(out_driveDirection, setpoint > 0 ? LOW : HIGH);
          // Apply the PID output to the motor's PWM control
          //ledcWrite(pwmChannel, (uint32_t)output);
          //ledcWrite(out_driveThrottle, (uint32_t)filteredOutput);
          
        /*if(input*4>=setpoint*4)
          {
            setpoint=0;
            
            
          }
          else{
            setpoint=70;
            }*/
          // Print results
          // Serial.print("Target RPM: ");
          // Serial.print(setpoint*4);
          // Serial.print(", Current RPM: ");
          // Serial.print(input*4);
          // Serial.print(", PWM Output: ");
          // Serial.println(filteredOutput);
          lastTime = currentTime;  // Reset timer
          
        }
  }
  return (uint16_t)filteredOutput;
}