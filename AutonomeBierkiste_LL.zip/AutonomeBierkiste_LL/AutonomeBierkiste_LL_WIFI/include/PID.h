#ifndef PID_H
#define PID_H

#include <PID_v1.h>
#include <Arduino.h>
#include "pins.h"



volatile int counter = 0;  // Position counter (volatile for ISR safety)

// Encoder and drivetrain parameters
const int encoderPPR = 102;  // Pulses per revolution for the SNG-QPLA-000
const int encoderCPR = encoderPPR * 4;  // Counts per revolution for quadrature

// Sprocket configuration
const int drivingSprocketTeeth = 12;  // Driving sprocket (motor)
const int drivenSprocketTeeth = 36;  // Driven sprocket (wheel)
const float gearRatio = (float)drivenSprocketTeeth / drivingSprocketTeeth;

// Wheel configuration
//const float wheelDiameter = 0.5;  // Wheel diameter in meters
const float wheelCircumference = 0.48607;  // Circumference in meters 0.8765


// PID control variables
double setpoint = 0;  // Target speed in RPM (desired speed)
double input = 0;      // Current speed in RPM (from encoder)
double output = 0;     // PID output to control the motor speed
// PID tuning parameters (Kp, Ki, Kd)
double Kp = 2, Ki = 21, Kd = 0.1;

PID myPID(&input, &output, &setpoint, Kp, Ki, Kd, DIRECT); // (Kp, Ki, Kd), Direction

static double smoothedSetpoint = 0;
double rampRate = 0.5;
double decayRate = 10;

// Smoothing variables
double filteredOutput = 0;
double alpha = 0.2; // Smoothing factor (0 < alpha < 1)

unsigned long currentTime2;  // Get the current time
unsigned long lastTime = 0;  // Last time when speed was calculated
unsigned long interval = 100;  // Interval to calculate speed (in ms, 1000ms = 1 second)500
int previousCounter = 0;  // Store the previous counter value for speed calculation

double integralLimit = 60.0;






#endif