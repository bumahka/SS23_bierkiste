#ifndef EMERGENCY_BUTTON_H
#define EMERGENCY_BUTTON_H


#include <Arduino.h>
#include "pins.h"
#include <WiFi.h>
#include <RemoteXY.h>

/* defines */
// RemoteXY select connection mode and include library 
#define REMOTEXY_MODE__WIFI_POINT
// RemoteXY connection settings 
#define REMOTEXY_WIFI_SSID "Bierkiste"
#define REMOTEXY_WIFI_PASSWORD "12345678"
#define REMOTEXY_SERVER_PORT 6377
// RemoteXY GUI configuration  
#pragma pack(push, 1)  
uint8_t RemoteXY_CONF[] =   // 194 bytes
  { 255,1,0,7,0,187,0,19,0,0,0,0,31,1,106,200,1,1,5,0,
  2,29,66,44,22,0,2,26,31,31,79,78,0,79,70,70,0,73,15,135,
  14,32,116,128,9,135,26,0,0,0,0,0,0,200,66,0,0,0,0,135,
  0,0,72,66,0,0,112,66,94,0,0,112,66,0,0,180,66,36,0,0,
  180,66,0,0,200,66,73,48,135,14,32,116,128,9,135,26,0,0,0,0,
  0,0,200,66,0,0,0,0,135,0,0,72,66,0,0,112,66,94,0,0,
  112,66,0,0,180,66,36,0,0,180,66,0,0,200,66,73,83,135,14,32,
  116,128,9,135,26,0,0,0,0,0,0,200,66,0,0,0,0,135,0,0,
  72,66,0,0,112,66,94,0,0,112,66,0,0,180,66,36,0,0,180,66,
  0,0,200,66,70,81,68,18,18,32,26,37,135,0 };

#pragma pack(push, 1) 
// this structure defines all the variables and events of your control interface 
struct {

    // input variables
  uint8_t Switch; // =1 if switch ON and =0 if OFF

   // output variables
  int16_t Sensor_L; // from 0 to 100
  int16_t Sensor_M; // from 0 to 100
  int16_t Sensor_R; // from 0 to 100
  uint8_t indicator_led; // from 0 to 2

    // other variable
  uint8_t connect_flag;  // =1 if wire connected, else =0

} RemoteXY;   
#pragma pack(pop)

#endif