# ESP32 IO Documentation

|PIN|PROTOCOL|DT node|REMARK|DESCRIPTION|
|:-:|:-:|:-:|:-:|:-|
|0|GPIO||OUTPUT|Drive Direction|
|1|||||
|2|GPIO||INPUT| INTERRUPT_BREAK|
|3|||||
|4|GPIO||OUTPUT|Drive Trottle|
|5|GPIO||INPUT|Sensor Middle Trigger|
|6|SPI|||FLASH :x:|
|7|SPI|||FLASH :x:|
|8|SPI|||FLASH :x:|
|9|UART1|||FLASH :x:|
|10|UART1|||FLASH :x:|
|11|SPI|||FLASH :x:|
|12|||||
|13|||||
|14|||||
|15|||||
|16|UART2||Rx|Communication with Surface computer |
|17|UART2||Tx|communication with Surface computer |
|18|GPIO||INPUT|Sensor Right Echo|
|19|GPIO||INPUT|Sensor Right Trigger|
|21|GPIO||INPUT|Sensor Middle Echo|
|22|GPIO||INPUT|Sensor Left Echo|
|23|GPIO||INPUT|Sensor Left Trigger|
|25|GPIO||OUTPUT|N_STEERING_PULSE|
|26|GPIO||OUTPUT|P_STEERING_PULSE|
|27|GPIO||OUTPUT| brake|
|32|GPIO||OUTPUT|N_STEERING_DIRECTION|
|33|GPIO||OUTPUT|P_STEERING_DIRECTION |
|34|||||
|35|||||
|36|||||
|39|||||

## [Pin functionability reference](https://randomnerdtutorials.com/esp32-pinout-reference-gpios/)