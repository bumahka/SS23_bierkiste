#include "PID.h"



void handleEncoderInterrupt() {
    int channelAState = digitalRead(SPEED_SENSOR_A); // Read the state of Channel A
    int channelBState = digitalRead(SPEED_SENSOR_B); // Read the state of Channel B

  // Determine direction based on the state of Channel B
  if (channelBState != channelAState) {
    counter--;  // Moving forward
  } else {
    counter++;  // Moving backward
  }
}


void runPIDControl(int speed){
  unsigned long currentTime = millis();  // Get the current time
  setpoint = speed;  // Set the target speed (RPM)
  if (currentTime - lastTime >= interval) {
    // Calculate the change in position during the interval
    int positionChange = counter - previousCounter;
    previousCounter = counter;  // Update the previous counter value

    // Calculate motor speed in counts/second
    float speedInCountsPerSecond = positionChange / (interval / 1000.0);

    // Calculate motor RPM
    input = (speedInCountsPerSecond * 60) / encoderCPR;

    // Compute PID output (PWM value for motor speed control)
    myPID.Compute();

  
    //anti-windup
    double ITerm = myPID.GetITerm();
    if(ITerm > integralLimit){
      ITerm = integralLimit;
    }
    else if (ITerm < -integralLimit){
      ITerm = -integralLimit;
    }
    myPID.SetITerm(ITerm);
    filteredOutput = alpha * output + (1 - alpha) * filteredOutput;

    // Set motor direction based on the setpoint (direction of rotation)
    digitalWrite(out_driveDirection, setpoint > 0 ? LOW : HIGH);
    // Apply the PID output to the motor's PWM control
    //ledcWrite(pwmChannel, (uint32_t)output);
    ledcWrite(out_driveThrottle, (uint32_t)filteredOutput);
    
/*if(input*4>=setpoint*4)
    {
      setpoint=0;
      
      
    }
    else{
      setpoint=70;
      }*/
    // Print results
    /*Serial.print("Target RPM: ");
    Serial.print(setpoint*4);
    Serial.print(", Current RPM: ");
    Serial.print(input*4);
    Serial.print(", PWM Output: ");
    Serial.println(filteredOutput);*/
    lastTime = currentTime;  // Reset timer
  }
}